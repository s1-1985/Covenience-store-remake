/*
 * ps3mca-tool - PlayStation 3 Memory Card Adaptor Software
 * Copyright (C) 2011 - jimmikaelkael <jimmikaelkael@wanadoo.fr>
 * Copyright (C) 2011 - "someone who wants to stay anonymous"
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "util.h"

void memrcpy(void *dst, void *src, size_t len)
{
	size_t i;
	for (i = 0; i < len; i++) {
		((uint8_t *)dst)[i] = ((uint8_t *)src)[len-1-i];
	}
}

/*
 * memxor: perform exclusive-or of memory buffers.
 */
void memxor(const void *a, const void *b, void *Result, size_t Length)
{
	size_t i;
	for (i = 0; i < Length; i++) {
		((uint8_t *)Result)[i] = ((uint8_t *)a)[i] ^ ((uint8_t *)b)[i];
	}
}

/*
 * append_le_uint16: append an unsigned 16 bits Little Endian
 * value to a buffer
 */
void append_le_uint16(uint8_t *buf, uint16_t val)
{
	buf[0] = (uint8_t)val;
	buf[1] = (uint8_t)(val >> 8);
}

/*
 * append_le_uint32: append an unsigned 32 bits Little Endian
 * value to a buffer
 */
void append_le_uint32(uint8_t *buf, uint32_t val)
{
	buf[0] = (uint8_t)val;
	buf[1] = (uint8_t)(val >> 8);
	buf[2] = (uint8_t)(val >> 16);
	buf[3] = (uint8_t)(val >> 24);
}

/*
 * append_le_uint64: append an unsigned 64 bits Little Endian
 * value to a buffer
 */
void append_le_uint64(uint8_t *buf, uint64_t val)
{
	int i;
	for (i = 7; i >= 0; i--, val >>= 8) {
		buf[i] = (uint8_t)val;
	}
}

/*
 * read_le_uint16: read an unsigned 16 bits Little Endian
 * value from a buffer
 */
uint16_t read_le_uint16(const uint8_t *buf)
{
	register uint16_t val;

	val = buf[0];
	val |= (buf[1] << 8);

	return val;
}

/*
 * read_le_uint32: read an unsigned 32 bits Little Endian
 * value from a buffer
 */
uint32_t read_le_uint32(const uint8_t *buf)
{
	register uint32_t val;

	/* Cast before shifting: a uint8_t promotes to int, so buf[3] << 24 is a
	 * signed overflow for any byte >= 128 - undefined behaviour, which is what
	 * UBSan reports here. Every real compiler produces the wanted value, but
	 * the cast makes it defined. */
	val = buf[0];
	val |= ((uint32_t)buf[1] << 8);
	val |= ((uint32_t)buf[2] << 16);
	val |= ((uint32_t)buf[3] << 24);

	return val;
}

/*
 * read_le_uint64: read an unsigned 64 bits Little Endian
 * value from a buffer
 */
uint64_t read_le_uint64(const uint8_t *buf)
{
	uint64_t val = 0;
	int i;
	for (i = 0; i < 8; i++) {
		val = (val << 8) | buf[i];
	}

	return val;
}

int read_buffer(const char *file_path, uint8_t **buf, size_t *size)
{
	FILE *fp;
	uint8_t *file_buf;
	size_t file_size;

	if ((fp = fopen(file_path, "rb")) == NULL)
        return -1;
	fseek(fp, 0, SEEK_END);
	file_size = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	file_buf = (uint8_t *)malloc(file_size);
	fread(file_buf, 1, file_size, fp);
	fclose(fp);

	if (buf)
        *buf = file_buf;
	else
        free(file_buf);
	if (size)
        *size = file_size;

	return 0;
}

int write_buffer(const char *file_path, uint8_t *buf, size_t size)
{
	FILE *fp;

	if ((fp = fopen(file_path, "wb")) == NULL)
        return -1;
	fwrite(buf, 1, size, fp);
	fclose(fp);

	return 0;
}
