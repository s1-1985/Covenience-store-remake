/*
 * PS2VMC Tool - PS2 Virtual Memory Card Tool by Bucanero
 *
 * based on
 * ps3mca-tool - PlayStation 3 Memory Card Adaptor Software
 * Copyright (C) 2011 - jimmikaelkael <jimmikaelkael@wanadoo.fr>
 * Copyright (C) 2011 - "someone who wants to stay anonymous"
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <inttypes.h>

#include "mcio.h"
#include "util.h"
#include "ps2icon.h"
#include "psv_resign.h"
#include "ps2save.h"
#include "ps2blank.h"
#include "ps2png.h"
#include "ps2render.h"

#define PROGRAM_NAME    "PS2VMC-TOOL"
#define PROGRAM_VER     "2.0.0"

#define PSV_MAGIC       0x50535600

enum ps2vmc_cmd {
	CMD_NONE = 0,
	CMD_MCINFO,
	CMD_MCFREE,
	CMD_MCIMG,
	CMD_ECC_IMG,
	CMD_LIST,
	CMD_PSU_EXPORT,
	CMD_PSV_EXPORT,
	CMD_XPS_EXPORT,
	CMD_CBS_EXPORT,
	CMD_MAX_EXPORT,
	CMD_ICONS_RENDER,
	CMD_ICONS_PNG,
	CMD_EXTRACT,
	CMD_MCFORMAT,
	CMD_MCCREATE,
	CMD_INJECT,
	CMD_MKDIR,
	CMD_RMDIR,
	CMD_REMOVE,
	CMD_CROSSLINK,
	CMD_SAVE_IMPORT,
};


static void print_usage(int argc, char **argv)
{
	(void)argc;
	printf("Copyright (C) 2023-2026 - by Bucanero\n");
	printf("based on ps3mca-tool by jimmikaelkael et al.\n\n");
	printf("Usage:\n");
	printf("%s <VMC filepath> <command> [<arguments>]\n", argv[0]);
	printf("\n");
	printf("Available commands:\n");
	printf("\t --mc-info, -i\n");
	printf("\t --mc-free, -f\n");
	printf("\t --mc-image, -img <output filepath>\n");
	printf("\t --ecc-image, -ecc <output filepath>\n");
	printf("\t --mc-format\n");
	printf("\t --mc-create, -new  (write a new empty card to <VMC filepath>)\n");
	printf("\t --list, -ls <mc path>\n");
	printf("\t --icons-png <mc path>\n");
	printf("\t --3d-icons, -3d <mc path>  (software-rendered 3D icons)\n");
	printf("\t --extract-file, -x <mc filepath> <output filepath>\n");
	printf("\t --inject-file, -in <input filepath> <mc filepath>\n");
	printf("\t --make-directory, -mkdir <mc path>\n");
	printf("\t --remove-directory, -rmdir <mc path>\n");
	printf("\t --remove, -rm <mc filepath>\n");
	printf("\t --file-crosslink, -cl <real mc filepath> <dummy mc filepath>\n");
	printf("\t --import, -imp <save filepath>  (PSU, PSV, CBS, MAX or XPS)\n");
	printf("\t --psu-export, -psu <mc path> <output filepath>\n");
	printf("\t --psv-export, -psv <mc path> <output filepath>\n");
	printf("\t --xps-export, -xps <mc path> <output filepath>\n");
	printf("\t --cbs-export, -cbs <mc path> <output filepath>\n");
	printf("\t --max-export, -max <mc path> <output filepath>\n");
	printf("\n");
}

static int cmd_mcinfo(void)
{
	int r;
	int pagesize, blocksize, cardsize, cardflags;

	r = mcio_mcGetInfo(&pagesize, &blocksize, &cardsize, &cardflags);
	if (r < 0)
		return r;

	printf("PS2 Memory Card Information\n");
	printf("Page size:  %d bytes\n", pagesize);
	printf("Block size: %d pages\n", blocksize);
	printf("MC size:    %d MB\n", cardsize / 1024 / 1024);
	if (cardflags & 1)
		printf("MC claims to support ECC\n");
	if (cardflags & 8)
		printf("MC claims to support bad blocks management\n");
	printf("erase byte: 0x%02X\n", (cardflags & 16) ? 0x00 : 0xff);

	return 0;
}

static int cmd_mcfree(void)
{
	int r;
	int cardfree;

	printf("PS2 Memory Card free space\n");
	printf("Calculating free space...\n");

	r = mcio_mcGetAvailableSpace(&cardfree);
	if (r < 0)
		return r;

	printf("Available space: %d KB\n", cardfree / 1024);

	return 0;
}

static int cmd_mcimg(const char *output)
{
	int r, i;
	int pagesize, blocksize, cardsize, cardflags;

	r = mcio_mcGetInfo(&pagesize, &blocksize, &cardsize, &cardflags);
	if (r < 0)
		return -1;

	FILE *fh = fopen(output, "wb");
	if (fh == NULL)
		return -2;

	void *buf = malloc(pagesize);
	if (buf == NULL) {
		fclose(fh);
		return -3;
	}

	for (i = 0; i < (cardsize / pagesize); i++) {
		mcio_mcReadPage(i, buf, NULL);
		r = fwrite(buf, 1, pagesize, fh);
		if (r != pagesize) {
			free(buf);
			fclose(fh);
			return -4;
		}
	}

	fclose(fh);
	free(buf);

	printf("Exported raw memory card: %s\n", output);

	return 0;
}

static int cmd_ecc_img(const char *output)
{
	int r, i;
	int pagesize, blocksize, cardsize, cardflags;

	r = mcio_mcGetInfo(&pagesize, &blocksize, &cardsize, &cardflags);
	if (r < 0)
		return -1;

	FILE *fh = fopen(output, "wb");
	if (fh == NULL)
		return -2;

	void *ecc = malloc(pagesize >> 5);
	void *buf = malloc(pagesize);
	if (buf == NULL || ecc == NULL) {
		fclose(fh);
		return -3;
	}

	for (i = 0; i < (cardsize / pagesize); i++) {
		mcio_mcReadPage(i, buf, ecc);
		r = fwrite(buf, 1, pagesize, fh);
		if (r != pagesize) {
			free(buf);
			fclose(fh);
			return -4;
		}

		r = fwrite(ecc, 1, pagesize >> 5, fh);
		if (r != pagesize >> 5) {
			free(buf);
			fclose(fh);
			return -4;
		}
	}

	fclose(fh);
	free(buf);
	free(ecc);

	printf("Exported ECC memory card: %s\n", output);

	return 0;
}

static int cmd_export(const char* path, const char* output)
{
	int r, fd, dd, foundfile;
	struct io_dirent dirent;
	struct MCFsEntry entry;
	char filepath[256];

	printf("Exporting '%s' to %s...\n", path, output);

	dd = mcio_mcDopen(path);
	if (dd < 0)
		return dd;

	FILE *fh = fopen(output, "wb");
	if (fh == NULL) {
		return -1002;
	}

	// Read main directory entry
	mcio_mcStat(path, &dirent);

	memset(&entry, 0, sizeof(entry));
	memcpy(&entry.created, &dirent.stat.ctime, sizeof(struct sceMcStDateTime));
	memcpy(&entry.modified, &dirent.stat.mtime, sizeof(struct sceMcStDateTime));
	memcpy(entry.name, dirent.name, sizeof(entry.name));
	entry.mode = dirent.stat.mode;
	entry.length = dirent.stat.size;
	fwrite(&entry, sizeof(entry), 1, fh);

	// "."
	memset(entry.name, 0, sizeof(entry.name));
	strncpy(entry.name, ".", sizeof(entry.name));
	entry.length = 0;
	fwrite(&entry, sizeof(entry), 1, fh);

	// ".."
	strncpy(entry.name, "..", sizeof(entry.name));
	fwrite(&entry, sizeof(entry), 1, fh);

	do {
		r = mcio_mcDread(dd, &dirent);
		foundfile = r;
		if (r && (strcmp(dirent.name, ".")) && (strcmp(dirent.name, ".."))) {
			snprintf(filepath, sizeof(filepath), "%s/%s", path, dirent.name);
			printf("Adding %-48s | %8d bytes\n", filepath, dirent.stat.size);

			mcio_mcStat(filepath, &dirent);

			memset(&entry, 0, sizeof(entry));
			memcpy(&entry.created, &dirent.stat.ctime, sizeof(struct sceMcStDateTime));
			memcpy(&entry.modified, &dirent.stat.mtime, sizeof(struct sceMcStDateTime));
			memcpy(entry.name, dirent.name, sizeof(entry.name));
			entry.mode = dirent.stat.mode;
			entry.length = dirent.stat.size;
			fwrite(&entry, sizeof(entry), 1, fh);

			fd = mcio_mcOpen(filepath, sceMcFileAttrReadable | sceMcFileAttrFile);
			if (fd < 0)
				return fd;

			uint8_t *p = malloc(dirent.stat.size);
			if (p == NULL)
				return -1000;

			r = mcio_mcRead(fd, p, dirent.stat.size);
			if (r != (int)dirent.stat.size) {
				mcio_mcClose(fd);
				free(p);
				return -1001;
			}

			mcio_mcClose(fd);

			r = fwrite(p, 1, dirent.stat.size, fh);
			if (r != (int)dirent.stat.size) {
				fclose(fh);
				free(p);
				return -1003;
			}
			free(p);

			entry.length = (1024 - (dirent.stat.size % 1024)) % 1024;
			while(entry.length--)
				fputc(0xFF, fh);
		}
	} while (foundfile);

	mcio_mcDclose(dd);
	fclose(fh);

	printf("Save successfully exported to %s.\n", output);

	return dd;
}

/*
 * Export one save directory as a signed PS3 .PSV.
 *
 * Layout: psv_header_t, ps2_header_t, ps2_MainDirInfo_t, one ps2_FileInfo_t
 * per file, then the file data packed end to end with no padding.
 */
static int cmd_psv_export(const char* path, const char* output)
{
	int r, fd, dd, i, numFiles = 0;
	uint32_t dataPos, total = 0;
	struct io_dirent dirent;
	struct io_dirent *files = NULL;
	ps2_IconSys_t iconsys;
	psv_header_t psvh;
	ps2_header_t ps2h;
	ps2_MainDirInfo_t ps2md;
	ps2_FileInfo_t *ps2fi = NULL;
	char filepath[256];
	FILE *fh;

	printf("Exporting '%s' to %s...\n", path, output);

	dd = mcio_mcDopen(path);
	if (dd < 0)
		return dd;

	/* first pass: collect the files, with the stat() mode the PSV wants
	 * (mcio_mcDread rebuilds mode from a subset of the flags) */
	do {
		r = mcio_mcDread(dd, &dirent);
		if (r && strcmp(dirent.name, ".") && strcmp(dirent.name, "..")) {
			struct io_dirent *tmp = realloc(files, (numFiles + 1) * sizeof(struct io_dirent));
			if (!tmp) {
				free(files);
				mcio_mcDclose(dd);
				return -1000;
			}
			files = tmp;

			snprintf(filepath, sizeof(filepath), "%s/%s", path, dirent.name);
			if (mcio_mcStat(filepath, &files[numFiles]) < 0)
				files[numFiles] = dirent;

			total += files[numFiles].stat.size;
			numFiles++;
		}
	} while (r);

	mcio_mcDclose(dd);

	if (!numFiles) {
		free(files);
		fprintf(stderr, "Error: '%s' holds no files\n", path);
		return -1001;
	}

	/* the directory entry itself */
	if (mcio_mcStat(path, &dirent) < 0) {
		free(files);
		return -1002;
	}

	/* icon.sys names the three icons the PS3 shows */
	memset(&iconsys, 0, sizeof(iconsys));
	snprintf(filepath, sizeof(filepath), "%s/icon.sys", path);
	fd = mcio_mcOpen(filepath, sceMcFileAttrReadable | sceMcFileAttrFile);
	if (fd >= 0) {
		mcio_mcRead(fd, &iconsys, sizeof(ps2_IconSys_t));
		mcio_mcClose(fd);
	}

	ps2fi = calloc(numFiles, sizeof(ps2_FileInfo_t));
	if (!ps2fi) {
		free(files);
		return -1000;
	}

	dataPos = sizeof(psv_header_t) + sizeof(ps2_header_t) +
		  sizeof(ps2_MainDirInfo_t) + sizeof(ps2_FileInfo_t) * numFiles;

	memset(&psvh, 0, sizeof(psvh));
	memcpy(psvh.magic, "\0VSP", 4);
	memcpy(psvh.salt, "www.bucanero.com.ar", 20);
	append_le_uint32((uint8_t*) &psvh.headerSize, 0x2C);
	append_le_uint32((uint8_t*) &psvh.saveType, 2);

	memset(&ps2h, 0, sizeof(ps2h));
	append_le_uint32((uint8_t*) &ps2h.numberOfFiles, numFiles);
	append_le_uint32((uint8_t*) &ps2h.displaySize, total);

	memset(&ps2md, 0, sizeof(ps2md));
	memcpy(&ps2md.create, &dirent.stat.ctime, sizeof(struct sceMcStDateTime));
	memcpy(&ps2md.modified, &dirent.stat.mtime, sizeof(struct sceMcStDateTime));
	memcpy(ps2md.filename, dirent.name, sizeof(ps2md.filename));
	append_le_uint32((uint8_t*) &ps2md.numberOfFilesInDir, dirent.stat.size);
	append_le_uint32((uint8_t*) &ps2md.attribute, dirent.stat.mode);

	/* second pass: file entries, and where each one lands */
	for (i = 0; i < numFiles; i++) {
		memcpy(&ps2fi[i].create, &files[i].stat.ctime, sizeof(struct sceMcStDateTime));
		memcpy(&ps2fi[i].modified, &files[i].stat.mtime, sizeof(struct sceMcStDateTime));
		memcpy(ps2fi[i].filename, files[i].name, sizeof(ps2fi[i].filename));
		append_le_uint32((uint8_t*) &ps2fi[i].filesize, files[i].stat.size);
		append_le_uint32((uint8_t*) &ps2fi[i].attribute, files[i].stat.mode);
		append_le_uint32((uint8_t*) &ps2fi[i].positionInFile, dataPos);

		if (strcmp(files[i].name, "icon.sys") == 0) {
			append_le_uint32((uint8_t*) &ps2h.sysPos, dataPos);
			append_le_uint32((uint8_t*) &ps2h.sysSize, files[i].stat.size);
		}
		if (strcmp(files[i].name, iconsys.IconName) == 0) {
			append_le_uint32((uint8_t*) &ps2h.icon1Pos, dataPos);
			append_le_uint32((uint8_t*) &ps2h.icon1Size, files[i].stat.size);
		}
		if (strcmp(files[i].name, iconsys.copyIconName) == 0) {
			append_le_uint32((uint8_t*) &ps2h.icon2Pos, dataPos);
			append_le_uint32((uint8_t*) &ps2h.icon2Size, files[i].stat.size);
		}
		if (strcmp(files[i].name, iconsys.deleteIconName) == 0) {
			append_le_uint32((uint8_t*) &ps2h.icon3Pos, dataPos);
			append_le_uint32((uint8_t*) &ps2h.icon3Size, files[i].stat.size);
		}

		dataPos += files[i].stat.size;
	}

	fh = fopen(output, "wb");
	if (!fh) {
		free(ps2fi);
		free(files);
		return -1003;
	}

	fwrite(&psvh, sizeof(psvh), 1, fh);
	fwrite(&ps2h, sizeof(ps2h), 1, fh);
	fwrite(&ps2md, sizeof(ps2md), 1, fh);
	fwrite(ps2fi, sizeof(ps2_FileInfo_t), numFiles, fh);

	for (i = 0; i < numFiles; i++) {
		uint8_t *buf;

		snprintf(filepath, sizeof(filepath), "%s/%s", path, files[i].name);
		printf("Adding %-48s | %8d bytes\n", filepath, files[i].stat.size);

		fd = mcio_mcOpen(filepath, sceMcFileAttrReadable | sceMcFileAttrFile);
		if (fd < 0) {
			fclose(fh);
			free(ps2fi);
			free(files);
			return fd;
		}

		buf = malloc(files[i].stat.size ? files[i].stat.size : 1);
		if (!buf) {
			mcio_mcClose(fd);
			fclose(fh);
			free(ps2fi);
			free(files);
			return -1000;
		}

		r = files[i].stat.size ? mcio_mcRead(fd, buf, files[i].stat.size) : 0;
		mcio_mcClose(fd);

		if (r != (int) files[i].stat.size) {
			free(buf);
			fclose(fh);
			free(ps2fi);
			free(files);
			return -1004;
		}

		fwrite(buf, 1, files[i].stat.size, fh);
		free(buf);
	}

	fclose(fh);
	free(ps2fi);
	free(files);

	/* a PSV is rejected without its signature */
	if (!psv_resign(output))
		return -1005;

	printf("Save successfully exported to %s.\n", output);

	return 0;
}

static int cmd_export_icons_png(const char* path)
{
	int r, fd;
	ps2_IconSys_t iconsys;
	char filePath[256];
	uint8_t* output;
	char* fnames[4] = { iconsys.IconName, iconsys.copyIconName, iconsys.deleteIconName, NULL };

	if (path[0] == '/') path++;
	printf("Exporting '%s' icons...\n", path);

	snprintf(filePath, sizeof(filePath), "%s/icon.sys", path);
	fd = mcio_mcOpen(filePath, sceMcFileAttrReadable | sceMcFileAttrFile);
	if (fd < 0)
		return fd;

	r = mcio_mcRead(fd, &iconsys, sizeof(ps2_IconSys_t));
	if (r != (int)sizeof(ps2_IconSys_t)) {
		mcio_mcClose(fd);
		return -1001;
	}
	mcio_mcClose(fd);

	printf("- List icon  : %s\n", fnames[0]);
	printf("- Copy icon  : %s\n", fnames[1]);
	printf("- Delete icon: %s\n", fnames[2]);

	for (int i = 0; i < 3; i++) {
		output = getIconPS2(path, fnames[i]);
		if (!output) {
			return -1002;
		}

		fnames[3] = strrchr(fnames[i], '.');
		if (fnames[3]) {
			*fnames[3] = 0;
		}

		snprintf(filePath, sizeof(filePath), "%.12s_%s.png", path, fnames[i]);

		FILE *fh = fopen(filePath, "wb");
		if (fh == NULL) {
			return -1003;
		}

		r = png_write_rgba(fh, output, 128, 128);
		fclose(fh);
		free(output);

		if (r < 0) {
			fprintf(stderr, "Error: can't write '%s'\n", filePath);
			return -1003;
		}

		printf("Icon successfully exported to %s\n", filePath);
	}

	return 0;
}

/*
 * Render the three icons of a save the way the web page draws them, rather
 * than dumping the flat texture as --icons-png does.
 *
 * The background is left transparent so the PNG composites anywhere;
 * ps2icon_render() can also paint the icon.sys gradient.
 */
#define RENDER_SIZE   256
#define RENDER_SUPER  4

static int cmd_render_icons(const char* path)
{
	int r, fd;
	ps2_IconSys_t iconsys;
	char filePath[256];
	char* fnames[4] = { iconsys.IconName, iconsys.copyIconName, iconsys.deleteIconName, NULL };

	if (path[0] == '/') path++;
	printf("Rendering '%s' icons at %dx%d...\n", path, RENDER_SIZE, RENDER_SIZE);

	snprintf(filePath, sizeof(filePath), "%s/icon.sys", path);
	fd = mcio_mcOpen(filePath, sceMcFileAttrReadable | sceMcFileAttrFile);
	if (fd < 0)
		return fd;

	r = mcio_mcRead(fd, &iconsys, sizeof(ps2_IconSys_t));
	if (r != (int)sizeof(ps2_IconSys_t)) {
		mcio_mcClose(fd);
		return -1001;
	}
	mcio_mcClose(fd);

	for (int i = 0; i < 3; i++) {
		ps2icon_t icon;
		uint8_t *pixels;
		FILE *fh;

		if (ps2icon_load(path, fnames[i], &icon) < 0) {
			fprintf(stderr, "Warning: can't read icon '%s', skipping\n", fnames[i]);
			continue;
		}

		r = ps2icon_render(&icon, &iconsys, RENDER_SIZE, RENDER_SUPER,
				   PS2RENDER_BG_TRANSPARENT, &pixels);
		ps2icon_free(&icon);

		if (r < 0) {
			fprintf(stderr, "Warning: can't render icon '%s', skipping\n", fnames[i]);
			continue;
		}

		fnames[3] = strrchr(fnames[i], '.');
		if (fnames[3])
			*fnames[3] = 0;

		snprintf(filePath, sizeof(filePath), "%.12s_%s_3d.png", path, fnames[i]);

		fh = fopen(filePath, "wb");
		if (!fh) {
			free(pixels);
			return -1003;
		}

		r = png_write_rgba(fh, pixels, RENDER_SIZE, RENDER_SIZE);
		fclose(fh);
		free(pixels);

		if (r < 0) {
			fprintf(stderr, "Error: can't write '%s'\n", filePath);
			return -1003;
		}

		printf("Icon successfully rendered to %s\n", filePath);
	}

	return 0;
}

static int cmd_mcformat(void)
{
	int r;

	printf("PS2 Memory Card format\n");
	printf("Formating MC...\n");

	r = mcio_mcFormat();
	if (r < 0)
		return r;

	printf("Memory card successfully formatted.\n");

	return 0;
}

static int cmd_list(char *path)
{
	int r, fd;

	fd = mcio_mcDopen(path);
	if (fd >= 0) {
		struct io_dirent dirent;
		printf("---------- Filename ----------  |  Type  |   Size   | Attribs | Last Modification (UTC)\n");
		do {
			r = mcio_mcDread(fd, &dirent);
			if ((r)) { /* && (strcmp(dirent.name, ".")) && (strcmp(dirent.name, ".."))) { */
				printf("%-32s| %s | ", dirent.name, (dirent.stat.mode & sceMcFileAttrSubdir) ? "<dir> " : "<file>");
				printf("%8d | ", dirent.stat.size);
				printf("%c%c%c%c%c%c%c | ", (dirent.stat.mode & sceMcFileAttrReadable) ? 'r' : '-', 
					(dirent.stat.mode & sceMcFileAttrWriteable) ? 'w' : '-',
					(dirent.stat.mode & sceMcFileAttrExecutable) ? 'x' : '-',
					(dirent.stat.mode & sceMcFileAttrDupProhibit) ? 'p' : '-',
					(dirent.stat.mode & sceMcFileAttrHidden) ? 'H' : '-',
					(dirent.stat.mode & sceMcFileAttrPDAExec) ? 'S' : '-',
					(dirent.stat.mode & sceMcFileAttrPS1) ? '1' : '-');
				printf("%02d/%02d/%04d-", dirent.stat.mtime.Month, dirent.stat.mtime.Day, dirent.stat.mtime.Year);
				printf("%02d:%02d:%02d", dirent.stat.mtime.Hour, dirent.stat.mtime.Min, dirent.stat.mtime.Sec);
				printf("\n");
			}
		} while (r);

		mcio_mcDclose(fd);
	}

	return fd;
}

static int cmd_extract(char *filepath, char *output)
{
	int fd, r;

	printf("Reading file: '%s'...\n", filepath);

	fd = mcio_mcOpen(filepath, sceMcFileAttrReadable | sceMcFileAttrFile);
	if (fd < 0)
		return fd;

	int filesize = mcio_mcSeek(fd, 0, SEEK_END);
	mcio_mcSeek(fd, 0, SEEK_SET);
	uint8_t *p = malloc(filesize);
	if (p == NULL)
		return -1000;

	r = mcio_mcRead(fd, p, filesize);
	if (r != filesize) {
		mcio_mcClose(fd);
		free(p);
		return -1001;
	}

	mcio_mcClose(fd);

	FILE *fh = fopen(output, "wb");
	if (fh == NULL) {
		free(p);
		return -1002;
	}

	printf("Writing data to: '%s'...\n", output);

	r = fwrite(p, 1, filesize, fh);
	if (r != filesize) {
		fclose(fh);
		free(p);
		return -1003;
	}

	fclose(fh);

	free(p);

	return fd;
}

static int cmd_inject(char *input, char *filepath)
{
	int fd, r;

	FILE *fh = fopen(input, "rb");
	if (fh == NULL)
		return -1000;

	fseek(fh, 0, SEEK_END);
	int filesize = ftell(fh);
	if (!filesize) {
		fclose(fh);
		return -1001;
	}
	fseek(fh, 0, SEEK_SET);

	printf("Reading file: '%s'...\n", input);

	uint8_t *p = malloc(filesize);
	if (p == NULL) {
		return -1002;
	}

	r = fread(p, 1, filesize, fh);
	if (r != filesize) {
		fclose(fh);
		free(p);
		return -1003;
	}

	fclose(fh);

	printf("Writing data to: '%s'...\n", filepath);

	fd = mcio_mcOpen(filepath, sceMcFileCreateFile | sceMcFileAttrWriteable | sceMcFileAttrFile);
	if (fd < 0) {
		free(p);
		return fd;
	}

	r = mcio_mcWrite(fd, p, filesize);
	if (r != filesize) {
		mcio_mcClose(fd);
		free(p);
		return -1004;
	}

	mcio_mcClose(fd);

	free(p);

	return fd;
}

static int cmd_import(const char *input)
{
	int fd, r;
	char filepath[256];
	struct io_dirent entry;
	ps2_MainDirInfo_t *ps2md;
	ps2_FileInfo_t *ps2fi;

	FILE *fh = fopen(input, "rb");
	if (fh == NULL)
		return -1000;

	fread(&r, 1, sizeof(int), fh);
	if (r != PSV_MAGIC) {
		printf("Not a .PSV file\n");
		fclose(fh);
		return -1000;
	}

	fseek(fh, 0, SEEK_END);
	int filesize = ftell(fh);
	if (!filesize) {
		fclose(fh);
		return -1001;
	}
	fseek(fh, 0, SEEK_SET);

	printf("Reading file: '%s'...\n", input);

	uint8_t *p = malloc(filesize);
	if (p == NULL) {
		return -1002;
	}

	r = fread(p, 1, filesize, fh);
	if (r != filesize) {
		fclose(fh);
		free(p);
		return -1003;
	}

	fclose(fh);

	if (p[0x3C] != 0x02) {
		printf("Not a PS2 save file\n");
		free(p);
		return -1004;
	}

	/* A bad signature is reported, not enforced: several tools wrote .PSV
	 * files before the HMAC was understood, and those saves import fine. */
	switch (psv_verify(p, (size_t)filesize)) {
	case PSV_SIG_BAD:
		printf("Warning: this save's signature does not match its contents; "
		       "importing anyway.\n");
		break;
	case PSV_SIG_UNSIGNED:
		printf("Warning: this save carries no signature; importing anyway.\n");
		break;
	default:
		break;
	}

	ps2md = (ps2_MainDirInfo_t *)&p[0x68];
	ps2fi = (ps2_FileInfo_t *)&ps2md[1];

	printf("Writing data to: '/%s'...\n", ps2md->filename);

	r = mcio_mcMkDir(ps2md->filename);
	if (r < 0)
		fprintf(stderr, "Error: can't create directory '%s'... (%d)\n", ps2md->filename, r);
	else
		mcio_mcClose(r);

	for (int i = read_le_uint32((uint8_t*)&ps2md->numberOfFilesInDir); i > 2; i--, ps2fi++)
	{
		filesize = read_le_uint32((uint8_t*)&ps2fi->filesize);

		snprintf(filepath, sizeof(filepath), "%s/%s", ps2md->filename, ps2fi->filename);
		printf("Adding %-48s | %8d bytes\n", filepath, filesize);
		fd = mcio_mcOpen(filepath, sceMcFileCreateFile | sceMcFileAttrWriteable | sceMcFileAttrFile);
		if (fd < 0) {
			free(p);
			return fd;
		}

		r = mcio_mcWrite(fd, &p[read_le_uint32((uint8_t*)&ps2fi->positionInFile)], filesize);
		if (r != filesize) {
			mcio_mcClose(fd);
			free(p);
			return -1004;
		}
		mcio_mcClose(fd);

		mcio_mcStat(filepath, &entry);
		memcpy(&entry.stat.ctime, &ps2fi->create, sizeof(struct sceMcStDateTime));
		memcpy(&entry.stat.mtime, &ps2fi->modified, sizeof(struct sceMcStDateTime));
		entry.stat.mode = read_le_uint32((uint8_t*)&ps2fi->attribute);
		mcio_mcSetStat(filepath, &entry);
	}

	mcio_mcStat(ps2md->filename, &entry);
	memcpy(&entry.stat.ctime, &ps2md->create, sizeof(struct sceMcStDateTime));
	memcpy(&entry.stat.mtime, &ps2md->modified, sizeof(struct sceMcStDateTime));
	entry.stat.mode = read_le_uint32((uint8_t*)&ps2md->attribute);
	mcio_mcSetStat(ps2md->filename, &entry);

	free(p);

	return fd;
}

/*
 * Import a save file (PSU/PSV/CBS/MAX/XPS). The format is detected from the file
 * contents, so --import and the legacy --psu-import/--psv-import flags all land
 * in the same code path.
 */
/*
 * Export a save as one of the third-party containers. The two differ only in
 * the builder they call, so they share everything around it.
 */
static int cmd_save_export(const char *path, const char *output, const char *fmt,
			   int (*build)(const ps2save_t *, uint8_t **, size_t *))
{
	ps2save_t save;
	uint8_t *buf;
	size_t len;
	int r;

	r = ps2save_read_card(path, &save);
	if (r < 0) {
		fprintf(stderr, "Error: can't read '%s' from the card (%d)\n", path, r);
		return r;
	}

	printf("Exporting '%s' to %s...\n", path, output);

	for (int i = 0; i < save.file_count; i++)
		printf("Adding %s/%-40s | %8u bytes\n", save.dirname,
			save.files[i].name, save.files[i].size);

	r = build(&save, &buf, &len);
	ps2save_free(&save);

	if (r < 0) {
		fprintf(stderr, "Error: can't build %s from '%s' (%d)\n", fmt, path, r);
		return r;
	}

	if (write_buffer(output, buf, len) < 0) {
		fprintf(stderr, "Error: can't write '%s'\n", output);
		free(buf);
		return -1000;
	}

	free(buf);
	printf("Save successfully exported to %s.\n", output);
	return 0;
}

static int cmd_psu_import(const char *input);

/*
 * Import a save of any supported format. The container is identified from its
 * contents, never from the file name, by the same ps2save_detect() the web
 * build uses - so there is nothing for the caller to get wrong.
 */
static int cmd_save_import(const char *input)
{
	ps2save_t save;
	uint8_t *buf;
	size_t len;
	int r, fmt;

	if (read_buffer(input, &buf, &len) < 0) {
		fprintf(stderr, "Error: can't open file '%s'\n", input);
		return -1000;
	}

	fmt = ps2save_detect(buf, len);
	free(buf);

	/* PSU and PSV have their own readers already; hand them straight over. */
	if (fmt == PS2SAVE_PSU)
		return cmd_psu_import(input);

	if (fmt == PS2SAVE_PSV)
		return cmd_import(input);

	if (fmt != PS2SAVE_CBS && fmt != PS2SAVE_MAX && fmt != PS2SAVE_XPS) {
		fprintf(stderr, "Error: '%s' is not a PS2 save "
			"(expected PSU, PSV, CBS, MAX or XPS)\n", input);
		return PS2SAVE_ERR_FORMAT;
	}

	if (read_buffer(input, &buf, &len) < 0) {
		fprintf(stderr, "Error: can't open file '%s'\n", input);
		return -1000;
	}

	printf("Reading file: '%s'...\n", input);

	r = ps2save_parse(buf, len, &save);
	free(buf);

	if (r < 0) {
		fprintf(stderr, "Error: can't read '%s' as a PS2 save container: %s (%d)\n",
			input, ps2save_error_name(r), r);
		return r;
	}

	if (mcio_mcStat(save.dirname, &(struct io_dirent){0}) == sceMcResSucceed) {
		fprintf(stderr, "Error: the card already has a save named '%s'; "
			"remove it first with --remove-directory\n", save.dirname);
		ps2save_free(&save);
		return PS2SAVE_ERR_EXISTS;
	}

	printf("Writing %s data to: '/%s'...\n", ps2save_format_name(fmt), save.dirname);

	for (int i = 0; i < save.file_count; i++)
		printf("Adding %s/%-40s | %8u bytes\n", save.dirname,
			save.files[i].name, save.files[i].size);

	r = ps2save_write(&save);
	ps2save_free(&save);

	return r;
}

static int cmd_psu_import(const char *input)
{
	int fd, r;
	char filepath[256];
	struct io_dirent entry;
	struct MCFsEntry psu_entry, file_entry;

	FILE *fh = fopen(input, "rb");
	if (fh == NULL)
		return -1000;

	fseek(fh, 0, SEEK_END);
	r = ftell(fh);

	if (!r || r % 512) {
		printf("Not a .PSU file\n");
		fclose(fh);
		return -1000;
	}

	printf("Reading file: '%s'...\n", input);
	fseek(fh, 0, SEEK_SET);

	r = fread(&psu_entry, sizeof(struct MCFsEntry), 1, fh);
	if (!r) {
		fclose(fh);
		return -1003;
	}

	// Skip "." and ".."
	fseek(fh, sizeof(struct MCFsEntry)*2, SEEK_CUR);

	printf("Writing data to: '/%s'...\n", psu_entry.name);

	r = mcio_mcMkDir(psu_entry.name);
	if (r < 0)
		fprintf(stderr, "Error: can't create directory '%s'... (%d)\n", psu_entry.name, r);
	else
		mcio_mcClose(r);

	for (int i = psu_entry.length; i > 2; i--)
	{
		fread(&file_entry, 1, sizeof(struct MCFsEntry), fh);

		snprintf(filepath, sizeof(filepath), "%s/%s", psu_entry.name, file_entry.name);
		printf("Adding %-48s | %8d bytes\n", filepath, file_entry.length);
		fd = mcio_mcOpen(filepath, sceMcFileCreateFile | sceMcFileAttrWriteable | sceMcFileAttrFile);
		if (fd < 0) {
			return fd;
		}

		uint8_t *p = malloc(file_entry.length);
		fread(p, 1, file_entry.length, fh);

		r = mcio_mcWrite(fd, p, file_entry.length);
		free(p);

		if (r != (int)file_entry.length) {
			mcio_mcClose(fd);
			return -1004;
		}
		mcio_mcClose(fd);

		mcio_mcStat(filepath, &entry);
		memcpy(&entry.stat.ctime, &file_entry.created, sizeof(struct sceMcStDateTime));
		memcpy(&entry.stat.mtime, &file_entry.modified, sizeof(struct sceMcStDateTime));
		entry.stat.mode = file_entry.mode;
		mcio_mcSetStat(filepath, &entry);

		r = 1024 - (file_entry.length % 1024);
		if(r < 1024)
			fseek(fh, r, SEEK_CUR);
	}

	mcio_mcStat(psu_entry.name, &entry);
	memcpy(&entry.stat.ctime, &psu_entry.created, sizeof(struct sceMcStDateTime));
	memcpy(&entry.stat.mtime, &psu_entry.modified, sizeof(struct sceMcStDateTime));
	entry.stat.mode = psu_entry.mode;
	mcio_mcSetStat(psu_entry.name, &entry);

	return fd;
}

static int cmd_mkdir(char *path)
{
	printf("Creating directory: '%s'...\n", path);
	return mcio_mcMkDir(path);
}

static int cmd_rmdir(char *path)
{
	printf("Removing directory: '%s'...\n", path);
	return mcio_mcRmDir(path);
}

static int cmd_remove(char *path)
{
	printf("Removing file: '%s'...\n", path);
	return mcio_mcRemove(path);
}

static int cmd_crosslink(char *real_filepath, char *dummy_filepath)
{
	printf("Cross-linking file: '%s' to '%s'...\n", dummy_filepath, real_filepath);
	mcio_mcCreateCrossLinkedFile(real_filepath, dummy_filepath);
	return 0;
}


int main(int argc, char **argv)
{
	int r, cmd = CMD_NONE;
	char **cmd_args = NULL;
	uint8_t *data = NULL;
	size_t dsize;

	printf(PROGRAM_NAME " v" PROGRAM_VER "\n");


	if (argc-- < 3) {
		print_usage(argc, argv);
		return 1;
	}
	else {
		if (!strcmp(argv[2], "--mc-info") || !strcmp(argv[2], "-i")) {
			cmd = CMD_MCINFO;
		}
		else if (!strcmp(argv[2], "--mc-free") || !strcmp(argv[2], "-f")) {
			cmd = CMD_MCFREE;
		}
		else if (!strcmp(argv[2], "--mc-image") || !strcmp(argv[2], "-img")) {
			if (argc < 3) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_MCIMG;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--ecc-image") || !strcmp(argv[2], "-ecc")) {
			if (argc < 3) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_ECC_IMG;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--mc-format")) {
			cmd = CMD_MCFORMAT;
		}
		else if (!strcmp(argv[2], "--mc-create") || !strcmp(argv[2], "-new")) {
			cmd = CMD_MCCREATE;
		}
		else if (!strcmp(argv[2], "--list") || !strcmp(argv[2], "-ls")) {
			if (argc < 3) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_LIST;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--3d-icons") || !strcmp(argv[2], "-3d")) {
			if (argc < 3) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_ICONS_RENDER;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--icons-png")) {
			if (argc < 3) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_ICONS_PNG;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--extract-file") || !strcmp(argv[2], "-x")) {
			if (argc < 4) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_EXTRACT;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--inject-file") || !strcmp(argv[2], "-in")) {
			if (argc < 4) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_INJECT;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--make-directory") || !strcmp(argv[2], "-mkdir")) {
			if (argc < 3) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_MKDIR;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--remove-directory") || !strcmp(argv[2], "-rmdir")) {
			if (argc < 3) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_RMDIR;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--remove") || !strcmp(argv[2], "-rm")) {
			if (argc < 3) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_REMOVE;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--file-crosslink") || !strcmp(argv[2], "-cl")) {
			if (argc < 4) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_CROSSLINK;
			cmd_args = &argv[3];
		}
		/* One import for every format: the file says what it is, so the
		 * older spellings all land here too. --psu-import/-pu and
		 * --psv-import/-pi are kept because they shipped; they are no longer
		 * advertised. */
		else if (!strcmp(argv[2], "--import") || !strcmp(argv[2], "-imp") ||
			 !strcmp(argv[2], "--psu-import") || !strcmp(argv[2], "-pu") ||
			 !strcmp(argv[2], "--psv-import") || !strcmp(argv[2], "-pi")) {
			if (argc < 3) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_SAVE_IMPORT;
			cmd_args = &argv[3];
		}
		/* -px and -pv shipped, so they still work; they are not advertised.
		 * The short options now name the format, matching --import's family. */
		else if (!strcmp(argv[2], "--psu-export") || !strcmp(argv[2], "-psu") ||
			 !strcmp(argv[2], "-px")) {
			if (argc < 4) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_PSU_EXPORT;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--xps-export") || !strcmp(argv[2], "-xps")) {
			if (argc < 4) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_XPS_EXPORT;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--cbs-export") || !strcmp(argv[2], "-cbs")) {
			if (argc < 4) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_CBS_EXPORT;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--max-export") || !strcmp(argv[2], "-max")) {
			if (argc < 4) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_MAX_EXPORT;
			cmd_args = &argv[3];
		}
		else if (!strcmp(argv[2], "--psv-export") || !strcmp(argv[2], "-psv") ||
			 !strcmp(argv[2], "-pv")) {
			if (argc < 4) {
				print_usage(argc, argv);
				return 1;
			}
			cmd = CMD_PSV_EXPORT;
			cmd_args = &argv[3];
		}
		else {
			print_usage(argc, argv);
			return 1;
		}
	}

	/* Creating a card is the one command with no card to open: argv[1] is the
	 * file about to be written, and it is not expected to exist. */
	if (cmd == CMD_MCCREATE) {
		uint8_t *blank;
		size_t blank_len;

		if (ps2blank_create(&blank, &blank_len) < 0) {
			fprintf(stderr, "Error: can't build a new memory card\n");
			return 1;
		}

		printf("Creating a new %d MB memory card...\n",
			(int)(blank_len / 1024 / 1024));

		if (write_buffer(argv[1], blank, blank_len) < 0) {
			fprintf(stderr, "Error: can't write '%s'\n", argv[1]);
			free(blank);
			return 1;
		}

		free(blank);
		printf("VMC file saved: %s\n", argv[1]);
		return 0;
	}

	if (read_buffer(argv[1], &data, &dsize) < 0) {
		fprintf(stderr, "Error: failed to open VMC file... (%s)\n", argv[1]);
		return 1;
	}

	r = mcio_init(data, dsize);
	/*if (r == sceMcResNoFormat)
		fprintf(stderr, "Error: memory card not formatted...\n");*/
	if ((r != sceMcResNoFormat) && (r < 0)) {
		fprintf(stderr, "Error: no PS2 Memory Card detected... (%d)\n", r);
	}
	else {
		if (cmd == CMD_MCINFO) {
			r = cmd_mcinfo();
			if (r < 0)
				fprintf(stderr, "Error: can't get MC infos... (%d)\n", r);
		}
		else if (cmd == CMD_MCFREE) {
			r = cmd_mcfree();
			if (r == sceMcResNoFormat)
				fprintf(stderr, "Error: memory card is not formatted!\n");
			else if (r < 0)
				fprintf(stderr, "Error: can't get MC free space... (%d)\n", r);
		}
		else if (cmd == CMD_MCIMG) {
			r = cmd_mcimg(cmd_args[0]);
			if (r < 0)
				fprintf(stderr, "Error: can't create image file... (%d)\n", r);
		}
		else if (cmd == CMD_ECC_IMG) {
			r = cmd_ecc_img(cmd_args[0]);
			if (r < 0)
				fprintf(stderr, "Error: can't create image file... (%d)\n", r);
		}
		else if (cmd == CMD_ICONS_PNG) {
			r = cmd_export_icons_png(cmd_args[0]);
			if (r < 0)
				fprintf(stderr, "Error: can't export icons... (%d)\n", r);
		}
		else if (cmd == CMD_ICONS_RENDER) {
			r = cmd_render_icons(cmd_args[0]);
			if (r < 0)
				fprintf(stderr, "Error: can't render icons... (%d)\n", r);
		}
		else if (cmd == CMD_PSU_EXPORT) {
			r = cmd_export(cmd_args[0], cmd_args[1]);
			if (r < 0)
				fprintf(stderr, "Error: can't export save to PSU... (%d)\n", r);
		}
		else if (cmd == CMD_PSV_EXPORT) {
			r = cmd_psv_export(cmd_args[0], cmd_args[1]);
			if (r < 0)
				fprintf(stderr, "Error: can't export save to PSV... (%d)\n", r);
		}
		else if (cmd == CMD_XPS_EXPORT) {
			r = cmd_save_export(cmd_args[0], cmd_args[1], "an XPS",
					    ps2save_build_xps);
			if (r < 0)
				fprintf(stderr, "Error: can't export save to XPS... (%d)\n", r);
		}
		else if (cmd == CMD_CBS_EXPORT) {
			r = cmd_save_export(cmd_args[0], cmd_args[1], "a CBS",
					    ps2save_build_cbs);
			if (r < 0)
				fprintf(stderr, "Error: can't export save to CBS... (%d)\n", r);
		}
		else if (cmd == CMD_MAX_EXPORT) {
			r = cmd_save_export(cmd_args[0], cmd_args[1], "a MAX",
					    ps2save_build_max);
			if (r < 0)
				fprintf(stderr, "Error: can't export save to MAX... (%d)\n", r);
		}
		else if (cmd == CMD_MCFORMAT) {
			r = cmd_mcformat();
			if (r < 0)
				fprintf(stderr, "Error: can't format MC... (%d)\n", r);
		}
		else if (cmd == CMD_LIST) {
			r = cmd_list(cmd_args[0]);
			if (r == sceMcResNoFormat)
				fprintf(stderr, "Error: memory card is not formatted!\n");
			else if (r == sceMcResNoEntry)
				fprintf(stderr, "Error: path '%s' not found...\n", cmd_args[0]);
			else if (r == sceMcResNotDir)
				fprintf(stderr, "Error: path '%s' is not a directory...\n", cmd_args[0]);
			else if (r < 0)
				fprintf(stderr, "Error: can't list directory '%s' (%d)\n", cmd_args[0], r);
		}
		else if (cmd == CMD_EXTRACT) {
			r = cmd_extract(cmd_args[0], cmd_args[1]);
			if (r == sceMcResNoFormat)
				fprintf(stderr, "Error: memory card is not formatted!\n");
			else if (r == sceMcResNotFile)
				fprintf(stderr, "Error: '%s' is not a file...\n", cmd_args[0]);
			else if (r < 0)
				fprintf(stderr, "Error: can't extract file '%s'... (%d)\n", cmd_args[0], r);
		}
		else if (cmd == CMD_INJECT) {
			r = cmd_inject(cmd_args[0], cmd_args[1]);
			if (r == sceMcResNoFormat)
				fprintf(stderr, "Error: memory card is not formatted!\n");
			else if (r < 0)
				fprintf(stderr, "Error: can't inject file '%s'... (%d)\n", cmd_args[0], r);
		}
		else if (cmd == CMD_MKDIR) {
			r = cmd_mkdir(cmd_args[0]);
			if (r == sceMcResNoFormat)
				fprintf(stderr, "Error: memory card is not formatted!\n");
			else if (r < 0)
				fprintf(stderr, "Error: can't create directory '%s'... (%d)\n", cmd_args[0], r);
		}
		else if (cmd == CMD_RMDIR) {
			r = cmd_rmdir(cmd_args[0]);
			if (r == sceMcResNoFormat)
				fprintf(stderr, "Error: memory card is not formatted!\n");
			else if (r < 0)
				fprintf(stderr, "Error: can't remove directory '%s'... (%d)\n", cmd_args[0], r);
		}
		else if (cmd == CMD_REMOVE) {
			r = cmd_remove(cmd_args[0]);
			if (r == sceMcResNoFormat)
				fprintf(stderr, "Error: memory card is not formatted!\n");
			else if (r < 0)
				fprintf(stderr, "Error: can't remove file '%s'... (%d)\n", cmd_args[0], r);
		}
		else if (cmd == CMD_CROSSLINK) {
			r = cmd_crosslink(cmd_args[0], cmd_args[1]);
			if (r < 0)
				fprintf(stderr, "Error: can't crosslink file '%s'... (%d)\n", cmd_args[0], r);
		}
		else if (cmd == CMD_SAVE_IMPORT) {
			r = cmd_save_import(cmd_args[0]);
			if (r == sceMcResNoFormat)
				fprintf(stderr, "Error: memory card is not formatted!\n");
			else if (r < 0)
				fprintf(stderr, "Error: can't import file '%s'... (%d)\n", cmd_args[0], r);
		}
	}

	/* save changes: every command after CMD_EXTRACT in the enum above
	 * modifies the card, the ones before it only read from it */
	if (cmd > CMD_EXTRACT && r == sceMcResSucceed) {
		write_buffer(argv[1], data, dsize);
		printf("VMC file saved: %s\n", argv[1]);
	}
	free(data);

	if (r < 0)
		return 1;

	return 0;
}
